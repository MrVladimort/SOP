#!/bin/bash

ls -lR|grep ^d|wc -l
