#!/bin/bash

T=(`ls`)
K=`ls -1|wc -l`
for((i=0;i<$K;i++))
 do
    if [ ! `grep '^[0-9]' ${T[$i]}` ]; then
	echo ${T[$i]}
    fi
 done
